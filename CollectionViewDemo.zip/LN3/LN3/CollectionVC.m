//
//  CollectionVC.m
//  LN3
//
//  Created by APPLE on 09/10/15.
//  Copyright (c) 2015 iossolution. All rights reserved.
//

#import "CollectionVC.h"
#import "CollectionCC.h"
#import "AFNetworking.h"
@interface CollectionVC (){
    NSMutableArray *arrThumbImage;
    NSMutableArray *arrFullName;
}

@end

@implementation CollectionVC

- (void)viewDidLoad {
    [super viewDidLoad];
    NSMutableDictionary *dict=[[NSMutableDictionary alloc]init];
    [dict setValue:@"0" forKey:@"album_id"];
    [dict setValue:@"19" forKey:@"wedding_id"];
    [dict setValue:@"377" forKey:@"user_id"];
    [dict setValue:@"1" forKey:@"page"];
    NSLog(@"Dict%@",dict);
    NSMutableDictionary *PostDict=[[NSMutableDictionary alloc]init];
    [PostDict setValue:dict forKey:@"data"];
    NSLog(@"Dict%@",PostDict);
    
#pragma Afnetworking Post Method:-
    NSString *strURL=@"http://trywedoo.com/wedoo/api/Album/GetPhotoAlbum";
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.requestSerializer=[AFJSONRequestSerializer serializer];
    manager.responseSerializer=[AFJSONResponseSerializer serializer];
    [manager POST:strURL parameters:PostDict success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSLog(@"JSON: %@", responseObject);
        arrFullName=[[NSMutableArray alloc]init];
        arrFullName=[[responseObject valueForKey:@"data"] valueForKey:@"fullname"];
        arrThumbImage=[[NSMutableArray alloc]init];
        arrThumbImage=[[responseObject valueForKey:@"data"] valueForKey:@"thumb_url"];
        NSLog(@"Thumb:%@",arrThumbImage);
        _collectionView.delegate=self;
        _collectionView.dataSource=self;
        [_collectionView reloadData];
        
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"Error: %@", error);
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma CollectionView Datasource Method
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return arrFullName.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    CollectionCC *objCollectionCC=[collectionView dequeueReusableCellWithReuseIdentifier:@"CollectionCC" forIndexPath:indexPath];
    objCollectionCC.imgThumb.imageURL=[NSURL URLWithString:[arrThumbImage objectAtIndex:indexPath.row]];
    objCollectionCC.lblTitle.text=[arrFullName objectAtIndex:indexPath.row];
    return objCollectionCC;
}






/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
