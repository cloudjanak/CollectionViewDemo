//
//  ViewController.m
//  LN3
//
//  Created by APPLE on 08/10/15.
//  Copyright (c) 2015 iossolution. All rights reserved.
//

#import "ViewController.h"
#import "AFNetworking.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSMutableDictionary *dictPost=[[NSMutableDictionary alloc] init];
    [dictPost setValue:@"0" forKey:@"album_id"];
    [dictPost setValue:@"19" forKey:@"wedding_id"];
    [dictPost setValue:@"377" forKey:@"user_id"];
    [dictPost setValue:@"1" forKey:@"page"];
    NSMutableDictionary *dict=[[NSMutableDictionary alloc] init];
    [dict setValue:dictPost forKey:@"data"];

    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.responseSerializer=[AFJSONResponseSerializer serializer];
    manager.requestSerializer=[AFJSONRequestSerializer serializer];
    [manager POST:@"http://trywedoo.com/wedoo/api/Album/GetPhotoAlbum" parameters:dict  success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSLog(@"JSON: %@", [[responseObject valueForKey:@"data"]valueForKey:@"thumb_url"]);
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"Error: %@", error);
    }];
    
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
